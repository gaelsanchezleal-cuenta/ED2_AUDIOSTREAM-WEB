/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gael.biblioteca_ep2;

/*
Carrera: IID  Grupo-grado: 4-A 
TITULO DE LA PRACTICA: EP1. Reporte de practica de estructuras de datos basicas

INTEGRANTES DE EQUIPO:
- Adan Gael Sanchez Leal - SLA0250028
- Aylin Yatzil Gomez Bocanegra - GBAO250171
- Melany Abigail Hernandez Perez - HPMO250279

 */
public class Nodo <T> {
    
    //ATRIBUTOS DE LA CLASE NODO
    private T elemento;
    private Nodo<T> siguiente;
    private Nodo<T> anterior;

    //CONSTRUCTOR CON PARAMETROS VACIOS PARA INICIALIZAR EL ELEMENTO COMO NULL
    public Nodo() {
        this.elemento = null;
        this.siguiente = siguiente;
        this.anterior = anterior;
    }
    
    //CONSTRUCTUR CON PARAMETRO ELEMENTO PARA QUE PUEDA RECIBIR VALORES
    public Nodo(T elemento) {
        this.elemento = elemento;
        this.siguiente = null;
        this.anterior = null;
    }

    //METODOS GET Y SET DE LOS ATRIBUTOS
    public T getElemento() {
        return elemento;
    }

    public void setElemento(T elemento) {
        this.elemento = elemento;
    }

    public Nodo<T> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo<T> siguiente) {
        this.siguiente = siguiente;
    }

    public Nodo<T> getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo<T> anterior) {
        this.anterior = anterior;
    }
    
    
}
