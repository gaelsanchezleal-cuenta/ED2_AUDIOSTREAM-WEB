/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.gael.biblioteca_ep2;

import java.util.InputMismatchException;
import java.util.Scanner;

/*
Carrera: IID  Grupo-grado: 4-A
TITULO DE LA PRACTICA: EP1. Reporte de practica de estructuras de datos basicas

INTEGRANTES DE EQUIPO:
- Adan Gael Sanchez Leal - SLA0250028
- Aylin Yatzil Gomez Bocanegra - GBAO250171
- Melany Abigail Hernandez Perez - HPMO250279

 */
public class Biblioteca_Ep2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Menu menu = new Menu();// Creamos el objeto para utilizar el menú principal
        Lista_Cir_Dob<Libro> biblioteca = new Lista_Cir_Dob<>();

        ////////////////// TENER YA 5 LIBROS GUARDADOS /////////////////////////
        //creacion de los objetos para guardar los 5
        Autor autor1 = new Autor("Gabriel", "Garcia", "Marquez");
        Libro libro1 = new Libro("Cien Años de Soledad", autor1, "15/05/1967", "Novela", "Sudamericana", 471, "Español");
        biblioteca.insertarInicio(libro1);

        Autor autor2 = new Autor("Mario", "Vargas", "Llosa");
        Libro libro2 = new Libro("La Ciudad y los Perros", autor2, "10/10/1963", "Novela", "Seix Barral", 344, "Español");
        biblioteca.insertarInicio(libro2);

        Autor autor3 = new Autor("Isabel", "Allende", "Llona");
        Libro libro3 = new Libro("La Casa de los Espiritus", autor3, "08/11/1982", "Novela", "Plaza & Janes", 464, "Español");
        biblioteca.insertarInicio(libro3);

        Autor autor4 = new Autor("Julio", "Cortazar", "Descotte");
        Libro libro4 = new Libro("Rayuela", autor4, "28/06/1963", "Novela", "Editorial Sudamericana", 600, "Español");
        biblioteca.insertarInicio(libro4);

        Autor autor5 = new Autor("Juan", "Rulfo", "Vizcaino");
        Libro libro5 = new Libro("Pedro Paramo", autor5, "19/03/1955", "Novela", "Fondo de Cultura Economica", 128, "Español");
        biblioteca.insertarInicio(libro5);

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // Instanciamos el objeto inicial
        Libro unLibro;

        int opcionPrincipal = 0;

        do {
            opcionPrincipal = menu.mostrarMenu(sc);// Mostramos el menú y guardamos la opción seleccionada

            System.out.println("--------------------------------------------------");

            switch (opcionPrincipal) {
                case 1:
                    System.out.println("SUBMENU: AGREGAR LIBRO");
                    System.out.println("1. Al Inicio");
                    System.out.println("2. En Medio");
                    System.out.println("3. Al Final");
                    System.out.print("Selecciona donde deseas agregar el libro: ");
                    try {
                        int opcionParaIngresar = sc.nextInt();
                        sc.nextLine();

                        switch (opcionParaIngresar) {
                            case 1:
                                unLibro = new Libro();
                                unLibro.capturar();
                                biblioteca.insertarInicio(unLibro);
                                System.out.println("Libro agregado al inicio");

                                System.out.println("--------------------------------------------------");
                                break;
                            case 2:
                                System.out.print("Ingresa la posición deseada: ");
                                int posicion;
                                try {
                                    posicion = sc.nextInt();
                                    sc.nextLine();
                                } catch (InputMismatchException e) {
                                    System.out.println("Posición no válida. Debes ingresar un número. Regresando al menú principal.");
                                    sc.nextLine();
                                    break;
                                }

                                unLibro = new Libro();
                                unLibro.capturar();
                                biblioteca.insertarMedio(unLibro, posicion);
                                System.out.println("Libro agregado a la posicion " + posicion);

                                System.out.println("--------------------------------------------------");
                                break;
                            case 3:
                                unLibro = new Libro();
                                unLibro.capturar();
                                biblioteca.insertarFinal(unLibro);
                                System.out.println("Libro agregado al final");

                                System.out.println("--------------------------------------------------");
                                break;
                            default:
                                System.out.println("Opción de agregación no válida.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada no válida. Debes ingresar un número. Regresando al menú principal.");
                        sc.nextLine();

                    }
                    break;

                case 2:
                    System.out.println("SUBMENU: ELIMINAR LIBRO");
                    System.out.println("1. Eliminar por Autor");
                    System.out.println("2. Eliminar por Título");
                    System.out.print("Selecciona porque metodo lo deseas eliminar: ");
                    try {
                        int opcionParaEliminar = sc.nextInt();
                        sc.nextLine();

                        switch (opcionParaEliminar) {

                            case 1:
                                System.out.print("Nombre del autor: ");
                                String nombreAutor = sc.nextLine().trim();

                                System.out.print("Apellido paterno: ");
                                String apellidoPaterno = sc.nextLine().trim();

                                System.out.print("Apellido materno: ");
                                String apellidoMaterno = sc.nextLine().trim();

                                System.out.print("Título del libro que deseas eliminar: ");
                                String titulo = sc.nextLine().trim();

                                Libro porAutor = biblioteca.eliminarPorAutor(nombreAutor, apellidoPaterno, apellidoMaterno, titulo);

                                if (porAutor != null) {
                                    System.out.println("================================================");
                                    System.out.println("Libro eliminado correctamente: " + porAutor);
                                } else {
                                    System.out.println("No se encontró un libro con ese título y autor.");
                                }

                                System.out.println("--------------------------------------------------");
                                break;

                            case 2:
                                System.out.print("Título del libro a eliminar: ");
                                String tituloLibro = sc.nextLine();

                                Libro porTitulo = biblioteca.eliminarPorTitulo(tituloLibro);
                                if (porTitulo != null) {
                                    System.out.println("Libro eliminado: " + porTitulo);
                                } else {
                                    System.out.println("No se encontró ningún libro con ese título.");
                                }

                                System.out.println("--------------------------------------------------");
                                break;

                            default:
                                System.out.println("Opción de eliminación no válida.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada no válida. Debes ingresar un número. Regresando al menú principal.");
                        sc.nextLine();
                    }
                    break;

                case 3:
                    System.out.println("SUBMENU: VISUALIZAR LIBROS");
                    System.out.println("1. Visualizar Alfabeticamente (A-Z)");
                    System.out.println("2. Visualizar Inverso (Z-A)");
                    System.out.print("Selecciona el tipo de visualizacion: ");
                    try {
                        int opcionParaVer = sc.nextInt();
                        sc.nextLine();

                        switch (opcionParaVer) {
                            case 1:
                                System.out.println("Libros en Orden (A-Z)");
                                System.out.println("--------------------------------------------------");

                                biblioteca.visualizarAlfabetico();

                                System.out.println("--------------------------------------------------");
                                break;
                            case 2:
                                System.out.println("Libros en Orden (Z-A)");
                                System.out.println("--------------------------------------------------");

                                biblioteca.visualizarInversoAlfabetico();

                                System.out.println("--------------------------------------------------");
                                break;
                            default:
                                System.out.println("Opción de visualización no válida.");
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Entrada no válida. Debes ingresar un número. Regresando al menú principal.");
                        sc.nextLine();
                    }
                    break;
                case 4:
                    System.out.print("Nombre del autor: ");
                    String nombreAutor = sc.nextLine().trim();
                    System.out.print("Apellido paterno: ");
                    String apellidoPaterno = sc.nextLine().trim();
                    System.out.print("Apellido materno: ");
                    String apellidoMaterno = sc.nextLine().trim();

                    int totalAutor = biblioteca.contadorPorNombre(nombreAutor, apellidoPaterno, apellidoMaterno);
                    System.out.println("Total de libros de este autor: " + totalAutor);
                    System.out.println("--------------------------------------------------");

                    biblioteca.mostrarPorNombre(nombreAutor, apellidoPaterno, apellidoMaterno);
                    System.out.println("--------------------------------------------------");
                    break;

                case 5:
                    System.out.print("Ingresa la fecha a buscar (ej. 2024 o 05/2024): ");
                    String fechaBuscar = sc.nextLine();

                    int totalFecha = biblioteca.contadorPorFecha(fechaBuscar);
                    System.out.println("Total de libros en esa fecha: " + totalFecha);
                    System.out.println("--------------------------------------------------");

                    biblioteca.mostrarPorFecha(fechaBuscar);
                    System.out.println("--------------------------------------------------");
                    break;

                case 6:

                    System.out.println("SUBMENU: MODIFICAR PUBLICACION");
                    System.out.print("Ingresa el título del libro a modificar: ");
                    String tituloAModificar = sc.nextLine().trim();

                    // Buscamos si el libro existe
                    Libro libroAModificar = biblioteca.buscarPorTitulo(tituloAModificar);

                    if (libroAModificar != null) {
                        System.out.println("Libro encontrado: " + libroAModificar);

                        System.out.print("Nueva Fecha de publicación (dd/mm/aaaa): ");
                        String nuevaFecha = sc.nextLine().trim();

                        System.out.print("Nuevo Idioma: ");
                        String nuevoIdioma = sc.nextLine().trim();

                        // Actualizamos los dos datos solicitados
                        libroAModificar.setFechaPublicacion(nuevaFecha);
                        libroAModificar.setIdioma(nuevoIdioma);

                        System.out.println("Fecha e idioma actualizados con exito");
                    } else {
                        System.out.println("No se encontro ningun libro con ese titulo.");
                    }

                    System.out.println("--------------------------------------------------");
                    break;

                default:
                    System.out.println("Opcion no valida.");
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    break;
            }

        } while (opcionPrincipal != 7);
    }
}
