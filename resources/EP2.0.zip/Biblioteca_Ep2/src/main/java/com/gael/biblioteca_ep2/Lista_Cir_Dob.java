package com.gael.biblioteca_ep2;

/*
Carrera: IID  Grupo-grado: 4-A
TITULO DE LA PRACTICA: EP1. Reporte de practica de estructuras de datos basicas

INTEGRANTES DE EQUIPO:
- Adan Gael Sanchez Leal - SLA0250028
- Aylin Yatzil Gomez Bocanegra - GBAO250171
- Melany Abigail Hernandez Perez - HPMO250279
 */
public class Lista_Cir_Dob<T> {

    // ATRIBUTOS DE LA CLASE LISTA_CIR_DOB
    private Nodo<T> inicio;
    private Nodo<T> fin;

    // CONSTRUCTOR VACIO INICIALIZANDO FIN E INICIO COMO NULL
    public Lista_Cir_Dob() {
        this.inicio = null;
        this.fin = null;
    }

    ////////////////// METODO PARA SABER SI ESTA VACIA LA LISTA //////////////////
    public boolean estaVacia() {
        return this.inicio == null;
    }

    //////////// METODO PARA INSERTAR ELEMENTOS A LA LISTA AL INICIO /////////////
    public void insertarInicio(T elemento) {
        if (estaVacia()) {
            Nodo<T> nuevoNodo = new Nodo<>();
            nuevoNodo.setElemento(elemento);

            nuevoNodo.setSiguiente(nuevoNodo);
            nuevoNodo.setAnterior(nuevoNodo);

            this.inicio = nuevoNodo;
            this.fin = nuevoNodo;
        } else {
            Nodo<T> nuevoNodo = new Nodo<>();
            nuevoNodo.setElemento(elemento);

            nuevoNodo.setSiguiente(this.inicio);
            nuevoNodo.setAnterior(this.fin);

            this.inicio.setAnterior(nuevoNodo);
            this.fin.setSiguiente(nuevoNodo);

            this.inicio = nuevoNodo;
        }
    }

    //////////// METODO PARA INSERTAR ELEMENTOS A LA LISTA AL FINAL //////////////
    public void insertarFinal(T elemento) {
        if (estaVacia()) {
            insertarInicio(elemento);
        } else {
            Nodo<T> nuevoNodo = new Nodo<>();
            nuevoNodo.setElemento(elemento);

            this.fin.setSiguiente(nuevoNodo);
            nuevoNodo.setAnterior(this.fin);
            nuevoNodo.setSiguiente(this.inicio);
            this.inicio.setAnterior(nuevoNodo);

            this.fin = nuevoNodo;
        }
    }

    //////////// METODO PARA INSERTAR ELEMENTOS A LA LISTA EN MEDIO //////////////
    public void insertarMedio(T elemento, int posicion) {
        if (estaVacia()) {
            insertarInicio(elemento);
        } else {
            Nodo<T> aux = this.inicio;
            int posicionActual = 1;

            if (posicion < 1) {
                System.out.println("Ingresa una posicion igual o mayor a 1");
            } else if (posicion == 1) {
                insertarInicio(elemento);
            } else {
                while (aux.getSiguiente() != this.inicio && posicionActual < (posicion - 1)) {
                    aux = aux.getSiguiente();
                    posicionActual++;
                }

                if (aux == this.fin) {
                    insertarFinal(elemento);
                } else {
                    Nodo<T> nuevoNodo = new Nodo<>();
                    nuevoNodo.setElemento(elemento);

                    nuevoNodo.setSiguiente(aux.getSiguiente());
                    nuevoNodo.setAnterior(aux);
                    aux.getSiguiente().setAnterior(nuevoNodo);

                    aux.setSiguiente(nuevoNodo);
                }
            }
        }
    }

    /////////////////////////// ELIMINAR AL INICIO /////////////////////////////
    public T eliminarInicio() {
        Nodo<T> aux = this.inicio;

        if (this.inicio == null) {
            return null;
        } else if (this.inicio == this.fin) {
            this.inicio = null;
            this.fin = null;
            return aux.getElemento();
        } else {
            this.inicio = this.inicio.getSiguiente();
            this.inicio.setAnterior(this.fin);
            this.fin.setSiguiente(this.inicio);

            return aux.getElemento();
        }
    }

    ///////////////////////////// ELIMINAR AL FINAL ////////////////////////////
    public T eliminarFinal() {
        if (this.inicio == null) {
            return null;
        } else if (this.inicio == this.fin) {
            return eliminarInicio();
        } else {
            Nodo<T> aux = this.inicio;
            while (aux.getSiguiente() != this.fin) {
                aux = aux.getSiguiente();
            }
            Nodo<T> aux1 = this.fin;

            this.fin = aux;
            this.fin.setSiguiente(this.inicio);
            this.inicio.setAnterior(this.fin);

            return aux1.getElemento();
        }
    }

    /////////////////////// METODOS PARA ELIMINAR (AUTOR O LIBRO) //////////////////////////////
    public T eliminarPorAutor(String nombre, String apellidoPaterno, String apellidoMaterno, String titulo) {
        if (estaVacia()) {
            return null;
        }

        nombre = nombre.trim();
        apellidoPaterno = apellidoPaterno.trim();
        apellidoMaterno = apellidoMaterno.trim();
        titulo = titulo.trim();

        Nodo<T> q = this.inicio;
        Nodo<T> p = null;

        do {
            Libro libroActual = (Libro) q.getElemento();
            Autor autorActual = libroActual.getAutor();

            if (autorActual.getNombre().trim().equalsIgnoreCase(nombre)
                    && autorActual.getApellidoPa().trim().equalsIgnoreCase(apellidoPaterno)
                    && autorActual.getApellidoMa().trim().equalsIgnoreCase(apellidoMaterno)
                    && libroActual.getTitulo().trim().equalsIgnoreCase(titulo)) {

                if (q == this.inicio) {
                    return eliminarInicio();
                } else if (q == this.fin) {
                    return eliminarFinal();
                } else {
                    p.setSiguiente(q.getSiguiente());
                    q.getSiguiente().setAnterior(p);
                    return q.getElemento();
                }
            }

            p = q;
            q = q.getSiguiente();

        } while (q != this.inicio);

        return null;
    }

    public T eliminarPorTitulo(String titulo) {
        if (estaVacia()) {
            return null;
        }

        titulo = titulo.trim();
        Nodo<T> q = this.inicio;
        Nodo<T> p = null;

        do {
            Libro libroActual = (Libro) q.getElemento();

            if (libroActual.getTitulo().trim().equalsIgnoreCase(titulo)) {
                if (q == this.inicio) {
                    return eliminarInicio();
                } else if (q == this.fin) {
                    return eliminarFinal();
                } else {
                    p.setSiguiente(q.getSiguiente());
                    q.getSiguiente().setAnterior(p);
                    return q.getElemento();
                }
            }

            p = q;
            q = q.getSiguiente();

        } while (q != this.inicio);

        return null;
    }

    ///////////////////////////////// METODO CONTADOR ////////////////////////////
    public Integer contador() {
        if (estaVacia()) {
            return 0;
        } else {
            Nodo<T> aux = this.inicio;
            Integer cantidad = 1;

            while (aux.getSiguiente() != this.inicio) {
                aux = aux.getSiguiente();
                cantidad++;
            }
            return cantidad;
        }
    }

    ///////////////// VISUALIZAR EN ORDEN ALFABETICO Y VICEVERSA /////////////////
    public void visualizarAlfabetico() {
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        } else {
            boolean intercambio;
            int cantidad = contador();

            do {
                intercambio = false;
                Nodo<T> aux = this.inicio;

                for (int i = 0; i < cantidad - 1; i++) {
                    Nodo<T> siguiente = aux.getSiguiente();

                    Libro libroActual = (Libro) aux.getElemento();
                    Libro libroSiguiente = (Libro) siguiente.getElemento();

                    if (libroActual.getTitulo().compareToIgnoreCase(libroSiguiente.getTitulo()) > 0) {
                        T auxElemento = aux.getElemento();
                        aux.setElemento(siguiente.getElemento());
                        siguiente.setElemento(auxElemento);

                        intercambio = true;
                    }

                    aux = aux.getSiguiente();
                }

            } while (intercambio);

            int contador = 0;
            Nodo<T> aux = this.inicio;
            while (contador < cantidad) {
                System.out.println(aux.getElemento());
                aux = aux.getSiguiente();
                contador++;
            }
        }
    }

    public void visualizarInversoAlfabetico() {
        if (estaVacia()) {
            System.out.println("La lista esta vacia");
        } else {
            boolean intercambio;
            int cantidad = contador();

            do {
                intercambio = false;
                Nodo<T> aux = this.inicio;

                for (int i = 0; i < cantidad - 1; i++) {
                    Nodo<T> siguiente = aux.getSiguiente();

                    Libro libroActual = (Libro) aux.getElemento();
                    Libro libroSiguiente = (Libro) siguiente.getElemento();

                    if (libroActual.getTitulo().compareToIgnoreCase(libroSiguiente.getTitulo()) < 0) {
                        T auxElemento = aux.getElemento();
                        aux.setElemento(siguiente.getElemento());
                        siguiente.setElemento(auxElemento);

                        intercambio = true;
                    }

                    aux = aux.getSiguiente();
                }

            } while (intercambio);

            int contador = 0;
            Nodo<T> aux = this.inicio;
            while (contador < cantidad) {
                System.out.println(aux.getElemento());
                aux = aux.getSiguiente();
                contador++;
            }
        }
    }

    ////////////////// METODO PARA CONTAR E IMPRIMIR LIBROS DE UN AUTOR //////////////////
    public Integer contadorPorNombre(String nombre, String apellidoPaterno, String apellidoMaterno) {
        if (estaVacia()) {
            return 0;
        } else {
            Nodo<T> aux = this.inicio;
            Integer cantidad = 0;

            do {
                Libro libroActual = (Libro) aux.getElemento();
                Autor autorActual = libroActual.getAutor();

                if (autorActual.getNombre().equalsIgnoreCase(nombre)
                        && autorActual.getApellidoPa().equalsIgnoreCase(apellidoPaterno)
                        && autorActual.getApellidoMa().equalsIgnoreCase(apellidoMaterno)) {
                    cantidad++;
                }

                aux = aux.getSiguiente();

            } while (aux != this.inicio);

            return cantidad;
        }
    }

    public void mostrarPorNombre(String nombre, String apellidoPaterno, String apellidoMaterno) {
        if (estaVacia()) {
            System.out.println("No existen libros con este autor");
        } else {
            Nodo<T> aux = this.inicio;
            boolean encontrado = false;

            do {
                Libro libroActual = (Libro) aux.getElemento();
                Autor autorActual = libroActual.getAutor();

                if (autorActual.getNombre().equalsIgnoreCase(nombre)
                        && autorActual.getApellidoPa().equalsIgnoreCase(apellidoPaterno)
                        && autorActual.getApellidoMa().equalsIgnoreCase(apellidoMaterno)) {

                    System.out.println(libroActual);
                    encontrado = true;
                }

                aux = aux.getSiguiente();

            } while (aux != this.inicio);

            if (!encontrado) {
                System.out.println("No existen libros registrados de este autor");
            }
        }
    }

    ////////////////// METODO PARA CONTAR E IMPRIMIR LIBROS POR UNA FECHA //////////////////
    public Integer contadorPorFecha(String fecha) {
        if (estaVacia()) {
            return 0;
        } else {
            Nodo<T> aux = this.inicio;
            Integer cantidad = 0;

            do {
                Libro libroActual = (Libro) aux.getElemento();

                if (libroActual.getFechaPublicacion().contains(fecha)) {
                    cantidad++;
                }

                aux = aux.getSiguiente();

            } while (aux != this.inicio);

            return cantidad;
        }
    }

    public void mostrarPorFecha(String fecha) {
        if (estaVacia()) {
            System.out.println("No hay libros encontrados en esa fecha");
        } else {
            Nodo<T> aux = this.inicio;
            boolean encontrado = false;

            do {
                Libro libroActual = (Libro) aux.getElemento();

                if (libroActual.getFechaPublicacion().contains(fecha)) {
                    System.out.println(libroActual);
                    encontrado = true;
                }

                aux = aux.getSiguiente();

            } while (aux != this.inicio);

            if (!encontrado) {
                System.out.println("No existen libros registrados de esa fecha");
            }
        }
    }

    ////////////////// METODO PARA BUSCAR UN LIBRO POR TITULO //////////////////
    public Libro buscarPorTitulo(String titulo) {
        if (estaVacia()) {
            return null;
        } else {
            Nodo<T> aux = this.inicio;

            do {
                Libro libroActual = (Libro) aux.getElemento();
                if (libroActual.getTitulo().equalsIgnoreCase(titulo.trim())) {
                    return libroActual;
                }
                aux = aux.getSiguiente();
            } while (aux != this.inicio);

            return null;
        }
    }
}
