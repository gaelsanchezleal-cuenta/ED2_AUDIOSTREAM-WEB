/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gael.biblioteca_ep2;

import java.util.InputMismatchException;
import java.util.Scanner;

/*
Carrera: IID  Grupo-grado: 4-A
TITULO DE LA PRACTICA: EP1. Reporte de practica de estructuras de datos basicas

INTEGRANTES DE EQUIPO:
- Adan Gael Sanchez Leal - SLA0250028
- Aylin Yatzil Gomez Bocanegra - GBAO250171
- Melany Abigail Hernandez Perez - HPMO250279

 */
public class Libro {

    //ATRIBUTOS PRINCPIALES
    private String titulo;
    private Autor autor;
    private String fechaPublicacion;
    private String tipoPublicacion;

    //3 CAMPOS PROPUESTOS
    private String editorial;
    private int numPaginas;
    private String idioma;

    //CONSTRUCTOR VACIO PARA PREVENIR ERRORES DE PUNTERO NULL
    // Se utiliza al agregar nuevos libros por teclado
    public Libro() {
        this.titulo = "";
        this.autor = new Autor();
        this.fechaPublicacion = "";
        this.tipoPublicacion = "";
        this.editorial = "";
        this.numPaginas = 0;
        this.idioma = "";
    }

    //// CONSTRUCTOR CON PARÁMETROS: Se utiliza para pre guardar los 5 libros pedidos al iniciar el programa
    public Libro(String titulo, Autor autor, String fechaPublicacion, String tipoPublicacion, String editorial, int numPaginas, String idioma) {
        this.titulo = titulo;
        this.autor = autor;
        this.fechaPublicacion = fechaPublicacion;
        this.tipoPublicacion = tipoPublicacion;
        this.editorial = editorial;
        this.numPaginas = numPaginas;
        this.idioma = idioma;
    }

    /*---------------- METODDO CAPTURAR ---------------------------*/
    public void capturar() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Titulo del libro: ");
        titulo = sc.nextLine();

        this.autor = new Autor();
        this.autor.capturar();

        boolean fechaValida = false;

        do {
            try {
                System.out.print("Fecha de publicacion (dd/mm/aaaa): ");
                fechaPublicacion = sc.nextLine();

                if (!(fechaPublicacion.trim().isEmpty())) {
                    fechaValida = true;
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("ERROR: ES OBLIGATORIO LLENAR ESTE CAMPO (ejemplo. 11/11/2007)");
            }
        } while (!fechaValida);

        System.out.print("Tipo de publicacion (ejemplo. Libro, Revista, etc): ");
        tipoPublicacion = sc.nextLine();

        System.out.print("Editorial: ");
        editorial = sc.nextLine();

        boolean paginasValidas = false;

        do {
            try {
                System.out.print("Numero de paginas: ");
                numPaginas = sc.nextInt();
                sc.nextLine();
                paginasValidas = true;
            } catch (InputMismatchException e) {
                System.out.println("ERROR: INGRESASTE UN CARACTER NO VALIDO");
                sc.nextLine();
            }
        } while (!paginasValidas);

        System.out.print("Idioma: ");
        idioma = sc.nextLine();
    }

    /*-----------------------------------------------------------------------*/
    public String getTitulo() {
        return titulo;
    }

    /*-----------------------------------------------------------------------*/
    public Autor getAutor() {
        return autor;
    }

    /*-----------------------------------------------------------------------*/
    public String getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(String fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    /*-----------------------------------------------------------------------*/
    public String getTipoPublicacion() {
        return tipoPublicacion;
    }

    /*-----------------------------------------------------------------------*/
    public String getEditorial() {
        return editorial;
    }

    /*-----------------------------------------------------------------------*/
    public int getNumPaginas() {
        return numPaginas;
    }

    /*-----------------------------------------------------------------------*/
    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    /*---------------- METODDO TO STRING ---------------------------*/
    @Override
    public String toString() {
        return "Contenido: Libro\n"
                + "Titulo: " + this.titulo + "\n"
                + "Fecha de publicacion: " + this.fechaPublicacion + "\n"
                + "Tipo de publicacion: " + this.tipoPublicacion + "\n"
                + "Editorial: " + this.editorial + "\n"
                + "Numero de paginas: " + this.numPaginas + "\n"
                + "Idioma: " + this.idioma + "\n"
                + "Autor:\n" + this.autor.toString() + "\n";
    }
}
