/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gael.biblioteca_ep2;

/**
 *
 * @author draic
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {

    public int mostrarMenu(Scanner sc) {
        System.out.println("========== SISTEMA DE BIBLIOTECA ==========");
        System.out.println("1. Agregar Libro");
        System.out.println("2. Eliminar Libro");
        System.out.println("3. Visualizar Todos los Libros");
        System.out.println("4. Visualizar Libros y cantidad por Autor");
        System.out.println("5. Visualizar Libros y cantidad por Fecha");
        System.out.println("6. Modificar libro");
        System.out.println("7. Salir");
        System.out.print("Selecciona una opcion: ");

        try {
            int opcion = sc.nextInt();
            sc.nextLine();
            return opcion;
        } catch (InputMismatchException e) {
            System.out.println("Opcion no valida, REINTENTALO.");
            sc.nextLine();
            return 0;
        }

    }
}
