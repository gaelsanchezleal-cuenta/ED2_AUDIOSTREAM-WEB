/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gael.biblioteca_ep2;

import java.util.Scanner;

/*
Carrera: IID  Grupo-grado: 4-A
TITULO DE LA PRACTICA: EP1. Reporte de practica de estructuras de datos basicas

INTEGRANTES DE EQUIPO:
- Adan Gael Sanchez Leal - SLA0250028
- Aylin Yatzil Gomez Bocanegra - GBAO250171
- Melany Abigail Hernandez Perez - HPMO250279

 */
public class Autor {

    private String nombre;
    private String apellidoPa;
    private String apellidoMa;

    //CONSTRUCTOR VACIO PARA PREVENIR ERRORES DE PUNTERO NULL
    // Se utiliza al agregar nuevos datos de autores por teclado
    public Autor() {
        this.nombre = "";
        this.apellidoPa = "";
        this.apellidoMa = "";
    }

    //CONSTRUCTOR CON PARAMATEROS
    //Se utiliza para pre guardar los datos de los autores de los 5 libros pedidos al iniciar el programa
    public Autor(String nombre, String apellidoPa, String apellidoMa) {
        this.nombre = nombre;
        this.apellidoPa = apellidoPa;
        this.apellidoMa = apellidoMa;
    }

    /*---------------- METODDO CAPTURAR ---------------------------*/
    public void capturar() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nombre del autor: ");
        nombre = sc.nextLine();

        System.out.print("Apellido paterno del autor: ");
        apellidoPa = sc.nextLine();

        System.out.print("Apellido materno del autor: ");
        apellidoMa = sc.nextLine();
    }

    /*-----------------------------------------------------------------------*/
    public String getNombre() {
        return nombre;
    }

    /*-----------------------------------------------------------------------*/
    public String getApellidoMa() {
        return apellidoMa;
    }

    /*-----------------------------------------------------------------------*/
    public String getApellidoPa() {
        return apellidoPa;
    }

    /*---------------- METODDO TO STRING ---------------------------*/
    @Override
    public String toString() {
        return "  Nombre: " + this.nombre + "\n"
                + "  Apellido paterno: " + this.apellidoPa + "\n"
                + "  Apellido materno: " + this.apellidoMa;
    }

}
